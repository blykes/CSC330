package edu.cuny.csi.csc330.lab4;

import java.util.*;

import edu.cuny.csi.csc330.lab1.Randomizer;

public class DrunkWalkTester {
	
	private Scanner input;
	public int steps;

	public DrunkWalkTester() {
		init();  
	}
	
	private void init() {
		input = new Scanner(System.in);
	}
	
	public void runTest(int steps ) { 
		
		
		System.out.print("Enter the starting avenue value: ");
		int avenue = input.nextInt();
		System.out.print("Enter the starting street value: ");
		int street = input.nextInt();
		
		//////////////////////// start test 
		// make the Drunkard with initial position
		Randomizer randomizer = new Randomizer();
		DrunkWalker billy = new DrunkWalker(avenue,street);
		DrunkWalker ozzy = new DrunkWalker(avenue,street);
/*
		// have him move/step 200 time 
		billy.fastForward(steps);
		ozzy.fastForward(steps);
		
		// get his current location
		String location = billy.getLocation();
		String location1 = ozzy.getLocation();
		// get distance from start
		int distance = billy.howFar();
		int distance1 = ozzy.howFar();

		System.out.println("Billy's " + location);
		System.out.println("That's " + distance + " blocks from start.");
		
		System.out.println("\n");
		
		System.out.println("Ozzy's " + location);
		System.out.println("That's " + distance + " blocks from start.");
		billy.displayWalkDetails();
		ozzy.displayWalkDetails();
		*/
		
		steps = randomizer.generateInt(1,300);
		 ozzy.fastForward(steps);
		 System.out.println("\nBilly took "+ steps +" steps\n" 
				 + "Billy's " + billy +"\n");
		 
		 steps = randomizer.generateInt(1,300);
		 ozzy.fastForward(steps);
		 System.out.println("Ozzy took "+ steps +" steps\n" 
				 + "Ozzy's " + ozzy);
		//////////////////// end test 


	}

	/**
	 * @param args 
	 * 
	 */
	public static void main(String[] args) {
		DrunkWalkTester tester = new DrunkWalkTester();
		
		int steps = 2000; 
		if(args.length == 1) {
			steps = Integer.parseInt(args[0]);
		}
		
		tester.runTest(steps); 
		
		System.exit(0);

	}

}
